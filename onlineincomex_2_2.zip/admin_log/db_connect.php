<?php 	
$localhost = "localhost";
$username = "onlineincomex_ar";
$password = "*L@JP{XZQGH{*L@JP{XZQGH{@";
$dbname = "onlineincomex_onlineincomex";

// db connection
$connect = new mysqli($localhost, $username, $password, $dbname);
// check connection
if($connect->connect_error) {
  die("Connection Failed : " . $connect->connect_error);
} else {
  // echo "Successfully connected";
}

?>