<?php
   header( "refresh:5;url=https://www.google.com" );
?>